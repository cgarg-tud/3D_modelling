/*
*	Copyright (C) 2015 by Liangliang Nan (liangliang.nan@gmail.com)
*	https://3d.bk.tudelft.nl/liangliang/
*
*	This file is part of the GEO1004 assignment code framework.
*/
#include <iostream>
#include <string>
#include "my_viewer.h"

#include <3rd_party/glew/include/GL/glew.h>		// for OpenGL functions
#include <3rd_party/glfw/include/GLFW/glfw3.h>	// for glfw functions

#include <easy3d/drawable.h>
#include <easy3d/point_cloud.h>
#include <easy3d/surface_mesh.h>
//#include <easy3d/box.h>

#include "normal_estimator.h"
#include "point_cloud_ransac.h"


//#include "eigen3/Eigen/Cholesky"

//for candidate faces
#include <set>
#include <list>
#include <map>
#include <eigen_solver.h>

//CGAL libararies
#if 0
#include <CGAL/Cartesian.h>
#include <CGAL/enum.h>
#include <CGAL/Plane_3.h>
#include <CGAL/Point_3.h>

#include <CGAL/Line_3.h>

#include <CGAL/intersections.h>

typedef CGAL::Cartesian<double> Kernel;
typedef CGAL::Point_3<Kernel>   Point_3;
typedef CGAL::Vector_3<Kernel>  Vector_3;
typedef CGAL::Plane_3<Kernel>   Plane_3;
typedef CGAL::Line_3<Kernel>   Line_3;
typedef std::vector<easy3d::vec3> Polygon3;

#else
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef CGAL::Point_3<Kernel>   Point_3;
typedef CGAL::Vector_3<Kernel>  Vector_3;
typedef CGAL::Plane_3<Kernel>   Plane_3;
typedef CGAL::Line_3<Kernel>   Line_3;
typedef std::vector<easy3d::vec3> Polygon3;
#endif


MyViewer::MyViewer()
    : easy3d::Viewer("A3_Reconstruction_of_the_coolest_team_so_far")
{
    std::cout <<
                 "-------------------------------------------------------------------\n"
                 "  E:               Estimation point cloud normals                  \n"
                 "  N:               Toggle the visualization of the normals         \n"
                 "  X:               Extract planes from point cloud using RANSAC     \n"
                 "  C:               Extract candidate faces" << std::endl;
}


MyViewer::~MyViewer()
{
}


bool MyViewer::key_press_event(int key, int modifiers)
{
    if (key == GLFW_KEY_E) {
        easy3d::PointCloud* cloud = point_cloud();
        NormalEstimator estimator;
        estimator.apply(cloud);

        easy3d::PointCloud::VertexProperty<easy3d::vec3> normals = cloud->get_vertex_property<easy3d::vec3>("v:normal");
        if (normals) { // normal estimation may fail, make sure the normals exist
            // -------------------------------------------------------
            // now we have the normal information, we can have a better
            // visualization of the point cloud. But we first need to
            // upload the normal information to GPU.
            easy3d::PointsDrawable* drawable = cloud->points_drawable("points");
            drawable->update_normal_buffer(normals.vector());

            // -------------------------------------------------------
            // this is for visualizing the normal vectors
            creat_normal_drawable(cloud);
        }

        return true;
    }
    else if (key == GLFW_KEY_N) {
        easy3d::PointCloud* cloud = point_cloud();
        if (cloud) {
            easy3d::LinesDrawable* lines = cloud->lines_drawable("normals");
            if (lines) {
                bool visible = lines->is_visible();
                lines->set_visible(!visible);
                update();
            }
            else
                creat_normal_drawable(cloud);
        }
        else
            std::cerr << "Warning: point cloud does not exist" << std::endl;
        return true;
    }
    else if (key ==GLFW_KEY_X){
        easy3d::PointCloud* cloud = point_cloud();
        if(cloud){
           easy3d::PointCloud::VertexProperty<easy3d::vec3> colors_pro = cloud->get_vertex_property<easy3d::vec3>("v:color");
           if(colors_pro){
              extract_planes(cloud);
          }
          else
          {
              easy3d::PointCloud::VertexProperty<easy3d::vec3> colors_pro = cloud->add_vertex_property<easy3d::vec3>("v:color");
              extract_planes(cloud);
          }
        }
        else
            std::cerr << "Warning: point cloud does not exist" << std::endl;


    }
    else if (key ==GLFW_KEY_C){
        easy3d::PointCloud* cloud = point_cloud();
        if(cloud){

           generate_candidate_faces(cloud);

        }
        else
            std::cerr << "Warning: point cloud does not exist" << std::endl;


    }

    else
        return Viewer::key_press_event(key, modifiers);
}



// Returns the pointer of the loaded point cloud.
// In case the model doesn't exist (e.g., not loaded to the viewer),
// it will return NULL (== 0).
easy3d::PointCloud* MyViewer::point_cloud()
{
    easy3d::PointCloud* cloud = dynamic_cast<easy3d::PointCloud*>(current_model());
    return cloud;
}


// create a drawable for visualizing the normals.
void MyViewer::creat_normal_drawable(easy3d::PointCloud* cloud)
{
    // it is always good to check if the input is valid
    if (cloud == nullptr) {
        std::cerr << "Warning: point cloud does not exist" << std::endl;
        return;
    }

    // the point normals (in type 'vec3') are stored in the "v:normal" property.
    easy3d::PointCloud::VertexProperty<easy3d::vec3> normals = cloud->get_vertex_property<easy3d::vec3>("v:normal");
    if (!normals) {
        std::cerr << "Warning: normal information does not exist" << std::endl;
        return;
    }

    // create a drawable and upload the necessary data to GPU to visualize the normals.
    // Note: a user may press the same button (i.e., running this function multiple times,
    //       so a good software implementation should check if the drawable already exists.
    //          - if no, create the drawable
    //          - if yes, no need to create the drawable, but just update the data transfered to
    //            the GPU to update the visualization.
    // ach drawable should have a unique name. Here we use "normals".


    easy3d::LinesDrawable* lines = cloud->lines_drawable("normals");
    if (!lines) {// this is equal to "lines == nullptr"
        std::cout << "creating drawable...[not implemented yet]" << std::endl;
        lines = cloud->add_lines_drawable("normals");
    }

    //-----------------------------------------------------------------
    // TODO: prepare the normal data (each normal is a line segment
    //       represented by its two end points). You can store them in
    //       a array of "std::vector". Check here for its usage:
    //       https://en.cppreference.com/w/cpp/container/vector

    easy3d::PointCloud::VertexProperty<easy3d::vec3> points = cloud->get_vertex_property<easy3d::vec3>("v:point");

    if (normals) {
        // Get the bounding box of the model. Then we defined the length of the
        // normal vectors to be 1% of the bounding box diagonal.
        easy3d::Box3 box;
        for (auto v : cloud->vertices())
            box.add_point(points[v]);
        float length = norm(box.max() - box.min()) * 0.01f;

        // Every consecutive two points represent a normal vector.
        std::vector<easy3d::vec3> normal_points;
        for (auto v : cloud->vertices()) {
            const easy3d::vec3& s = points[v];
            easy3d::vec3 n = normals[v];
            n.normalize();
            const easy3d::vec3& t = points[v] + n * length;
            normal_points.push_back(s);
            normal_points.push_back(t);
        }


        // Create a drawable for rendering the normal vectors.
        easy3d::LinesDrawable* normals_drawable = cloud->add_lines_drawable("normals");


        // Upload the data to the GPU.
        normals_drawable->update_vertex_buffer(normal_points);
        // We will draw the normal vectors in red color
        normals_drawable->set_per_vertex_color(false);
        normals_drawable->set_default_color(easy3d::vec3(139.0f, 0.0f, 0.0f));
    }
    else {
        std::cerr << "This point cloud does not have normal information. "
            "No vector field can be visualized." << std::endl;
    }



}
easy3d::vec3 random_color() {
    float r = rand() % 255 / 255.0f;	// in the range [0, 1]
    float g = rand() % 255 / 255.0f;	// in the range [0, 1]
    float b = rand() % 255 / 255.0f;	// in the range [0, 1]
    return easy3d::vec3(r, g, b);
}



void MyViewer::extract_planes(easy3d::PointCloud* cloud)
{   std::string min_number_string;
    unsigned int min_number;
    float dist_thresh;
    std::cout <<std::endl<< "Give minimum number of points required for a primitive:\nIf nothing is given the default value will be 100."<<std::endl;
    std::cin>>min_number;

    std::cout <<"Minimum number for segment: " << min_number <<" points."<<std::endl;

    std::cout <<std::endl<< "Give minimum distance threshold (relative to the bbox of the point cloud).\nIf nothing is given the default distance will be 0.005."<<std::endl;
    std::cin >> dist_thresh;
    std::cout <<"Minimum distance threshold set: " << dist_thresh <<std::endl;

    easy3d::PrimitivesRansac ransac;
    int prim_number=ransac.detect(cloud,min_number,dist_thresh);

    std::cout<< prim_number<<std::endl;
    int i;
    std::vector<easy3d::vec3> colors;
    easy3d::PointCloud::VertexProperty<int> segment_id = cloud->get_vertex_property<int>("v:segment_index");
    easy3d::PointCloud::VertexProperty<easy3d::vec3> colors_pro = cloud->get_vertex_property<easy3d::vec3>("v:color");

    for (i=0; i<prim_number; i++){
        easy3d::vec3 test= random_color();
        colors.push_back(test);

   }
    for (auto v : cloud->vertices()){

        //caution segment id equal to -1!!!!!!!!!!!
        if (segment_id[v]==-1){
            continue;
        }
        else{
        int seg_id=  segment_id[v];
        colors_pro[v] = colors[seg_id];

    }


}
easy3d::PointsDrawable* extract_drawable = cloud->points_drawable("points");
// Collect points, colors, and normals (if exist) and transfer them to GPU
auto points = cloud->get_vertex_property<easy3d::vec3>("v:point");
extract_drawable->update_vertex_buffer(points.vector());

auto colors_new = cloud->get_vertex_property<easy3d::vec3>("v:color");
if (colors_new)		// if colors exist
    extract_drawable->update_color_buffer(colors_new.vector());

extract_drawable->set_per_vertex_color(colors_new); // set to true if has color property
extract_drawable->set_default_color(easy3d::vec3(0.4f, 0.8f, 0.8f));
extract_drawable->set_point_size(3.0f);

update();
}


void MyViewer::generate_candidate_faces(easy3d::PointCloud* cloud)
{   easy3d::PointCloud::VertexProperty<easy3d::vec3> points = cloud->get_vertex_property<easy3d::vec3>("v:point");
    //easy3d::SurfaceMesh* mesh = new easy3d::SurfaceMesh;

    easy3d::LinesDrawable* bbox_drawable = cloud->add_lines_drawable("bbox");
    easy3d::Box3 box;
    // Compute the bounding box.

    for (auto v: cloud->vertices())
        box.add_point(points[v]);
    float extension = box.diagonal() * 0.05f;
    float xmin = box.x_min()-extension;	float xmax = box.x_max()+extension;
    float ymin = box.y_min()-extension;	float ymax = box.y_max()+extension;
    float zmin = box.z_min()-extension;	float zmax = box.z_max()+extension;



    // The eight vertices of the bounding box.
    const std::vector<easy3d::vec3> bbox_points = {
        easy3d::vec3(xmin, ymin, zmax), easy3d::vec3(xmax, ymin, zmax),
        easy3d::vec3(xmin, ymax, zmax),	easy3d::vec3(xmax, ymax, zmax),
        easy3d::vec3(xmin, ymin, zmin),	easy3d::vec3(xmax, ymin, zmin),
        easy3d::vec3(xmin, ymax, zmin),	easy3d::vec3(xmax, ymax, zmin)
    };
    const std::vector<unsigned int> bbox_indices = {
        0, 1, 2, 3, 4, 5, 6, 7,
        0, 2, 4, 6, 1, 3, 5, 7,
        0, 4, 2, 6, 1, 5, 3, 7
    };

    // Upload the vertex positions of the bounding box to the GPU.
    bbox_drawable->update_vertex_buffer(bbox_points);
    // Upload the vertex indices of the bounding box to the GPU.
    bbox_drawable->update_index_buffer(bbox_indices);
    bbox_drawable->set_default_color(easy3d::vec3(1.0f, 0.0f, 0.0f));	// red color

    update();

    std::vector<Line_3> bbox_lines;
    std::vector<Plane_3> box_planes;

    const std::vector<Point_3> box_points = {
        Point_3(xmin, ymin, zmax), Point_3(xmax, ymin, zmax),
        Point_3(xmin, ymax, zmax),	 Point_3(xmax, ymax, zmax),
        Point_3(xmin, ymin, zmin),	 Point_3(xmax, ymin, zmin),
        Point_3(xmin, ymax, zmin),	 Point_3(xmax, ymax, zmin)
    };

    bbox_lines.push_back(Line_3(box_points[0],box_points[1]));
    bbox_lines.push_back(Line_3(box_points[0],box_points[2]));
    bbox_lines.push_back(Line_3(box_points[0],box_points[4]));
    bbox_lines.push_back(Line_3(box_points[3],box_points[1]));
    bbox_lines.push_back(Line_3(box_points[3],box_points[2]));
    bbox_lines.push_back(Line_3(box_points[3],box_points[6]));
    bbox_lines.push_back(Line_3(box_points[5],box_points[1]));
    bbox_lines.push_back(Line_3(box_points[5],box_points[4]));
    bbox_lines.push_back(Line_3(box_points[5],box_points[6]));
    bbox_lines.push_back(Line_3(box_points[7],box_points[2]));
    bbox_lines.push_back(Line_3(box_points[7],box_points[4]));
    bbox_lines.push_back(Line_3(box_points[7],box_points[6]));

    box_planes.push_back(Plane_3(box_points[0],box_points[1],box_points[2]));
    box_planes.push_back(Plane_3(box_points[4],box_points[5],box_points[6]));
    box_planes.push_back(Plane_3(box_points[0],box_points[2],box_points[4]));
    box_planes.push_back(Plane_3(box_points[1],box_points[3],box_points[5]));
    box_planes.push_back(Plane_3(box_points[0],box_points[4],box_points[5]));
    box_planes.push_back(Plane_3(box_points[2],box_points[6],box_points[7]));


    easy3d::PointCloud::VertexProperty<int> segments = cloud->get_vertex_property<int>("v:segment_index");
    std::list<int> check_list;
    std::vector<easy3d::vec3> intersection_pts;

    std::vector<Polygon3> plane_vectors;

    std::vector< Polygon3 > polygons;
    std::vector< Polygon3 > cand_faces;
    std::vector<Plane_3> planes_equations;

    std::list<int>::iterator it;
//    std::map<int,std::vector<Plane_3>> planes;


    for (auto v: cloud->vertices())
    {
       int seg_id = segments[v];

       // Fetch the iterator of element with current segment id
       it = std::find(check_list.begin(), check_list.end(), seg_id);

       // Check if iterator points to end or not
       if(it != check_list.end())
       {
          // It does not point to end, it means element exists in list
          //if the plane is already done we continue
           continue;
       }
       else
       {
           // It points to end, it means element does not exists in list

           // first a plane is formed
           std::vector<easy3d::vec3> point_coordinates;
           for (auto v: cloud->vertices())
           {
             if(segments[v] == seg_id)
             {
              point_coordinates.push_back(points[v]);
             }
           }

           // introducing a centroid 3d vector
           ::vec3 cent;
           float n = point_coordinates.size();
           for (std::size_t j = 0; j<n; ++j) {

               cent(0) = cent(0) + point_coordinates[j][0];
               cent(1) = cent(1) + point_coordinates[j][1];
               cent(2) = cent(2) + point_coordinates[j][2];
           }
           cent(0)/= n;
           cent(1)/= n;
           cent(2)/= n;

           ::mat3 cov;
           ::vec3 temp;

           //creating 3D Matrix -covariance matrix using centroid vector
           for (std::size_t p = 0; p<n; ++p) {
               temp(0) = point_coordinates[p][0] - cent(0);
               temp(1) = point_coordinates[p][1] - cent(1);
               temp(2) = point_coordinates[p][2] - cent(2);

               for (int k = 0; k < 3; k++)
                   {
                       for (int l = 0; l < 3; l++)
                       {
                           cov(k,l) = cov(k,l) + temp(k)*temp(l);
                       }
                    }

           }

           // use eigen solver (implemented in Assignment_1) to estimate the normal of 'v'.
           ::EigenSolver eigen_solver;

           eigen_solver.solve(cov);
           float min_val = eigen_solver.get_eigen_value(0) ;
           int n_index = 0;

           for(int z = 0; z < 3; z++)
           {
               if(eigen_solver.get_eigen_value(z) < min_val)
               {
                   min_val = eigen_solver.get_eigen_value(z);
                   n_index = z;
               }
           }

           ::vec3 n_vec = eigen_solver.get_eigen_vector(n_index);

           easy3d::vec3 centroid;
           easy3d::vec3 seg_normal ;

           centroid[0] = cent(0);
           centroid[1] = cent(1);
           centroid[2] = cent(2);

           seg_normal[0] =  n_vec(0);
           seg_normal[1] =  n_vec(1);
           seg_normal[2] =  n_vec(2);

          Point_3 p1(centroid[0],centroid[1],centroid[2]);

          Vector_3 v1(seg_normal[0],seg_normal[1],seg_normal[2]);

          Plane_3 pl1(p1,v1);


          //add each plane to the dictionary planes

          Polygon3 plane_vector;
          plane_vector.push_back(centroid);
          plane_vector.push_back(seg_normal);
          planes_equations.push_back(pl1);
          plane_vectors.push_back(plane_vector);

          //plane done
          check_list.push_back(seg_id);
          point_coordinates.clear();
       }

    }

   //all planes extracted


// Declaring objects for storing the intersection
   CGAL::Object result;
   Point_3 int_point;
   Plane_3 int_plane;
   Line_3 int_line;   
   int count = 0;

// intersection of bbox and planes
  for (std::size_t i = 0; i < planes_equations.size(); ++i) {

       Plane_3 plane1 = planes_equations[i];
       Polygon3 polygon;

       for (std::size_t j = 0; j < bbox_lines.size(); ++j) {
            Line_3 line1 = bbox_lines[j];

             result = CGAL::intersection( plane1,line1);

                   if (CGAL::assign(int_point, result)) {

                       float x = int_point[0];
                       float y = int_point[1];
                       float z = int_point[2];

                     // store only points within bbox
                     bool b1 = xmin <= x && xmax >= x ;
                     bool b2 = ymin <= y && ymax >= y ;
                     bool b3 = zmin <= z && zmax >= z ;
                     if(b1 && b2 && b3)
                     {

                         easy3d::vec3 new_point(int_point[0],int_point[1],int_point[2]);

                         //creating each polygon
                         polygon.push_back(new_point);
                         intersection_pts.push_back(new_point);
                         count++;
                     }
                   }

       }

       // storing each bbox polygon in the final polygons
       polygons.push_back(polygon);

  }


  // Function for getting faces from polygons

  std::vector<std::vector<Polygon3>> faces;
  std::vector<float> box_limits = {xmin,xmax,ymin,ymax,zmin,zmax};

  float check1 = polygons.size()-1 ;
   std::size_t i = 0;

   while(check1 > 0){
       std::vector<Polygon3> cand_polygons ;
       cand_polygons.push_back(polygons[i]);

       std::vector<Polygon3> temp_polygons ;
       std::vector<Polygon3> split_polygons ;
       std::size_t j = 0;
       float check = planes_equations.size()-1 ;

       while(check > 0){

           if( i!=j ){

               for (std::size_t c = 0 ; c < cand_polygons.size(); ++c) {

                     split_polygons = split_polygon(cand_polygons[c],plane_vectors[j],planes_equations[j], box_limits);
                     if(split_polygons.size() > 0)
                     {
                         if(split_polygons[0].size() > 0)
                         {
                             temp_polygons.push_back(split_polygons[0]);
                         }
                         if(split_polygons[1].size() > 0)
                         {
                             temp_polygons.push_back(split_polygons[1]);
                         }

                     }
               }

               if(temp_polygons.size() > 0)
               {
                   cand_polygons = temp_polygons;
               }

           }
           ++j;
           --check;
       }


       faces.push_back(cand_polygons);
       ++i;
       --check1;
   }


   // Create a surface mesh and get candidate points
     easy3d::SurfaceMesh* mesh = new easy3d::SurfaceMesh;

       auto face_colors = mesh->add_face_property<easy3d::vec3>("f:color");

     for (auto polys : faces)
     {
     for (auto plg : polys)
     {

         if( plg.size() > 2)
         {
         std::vector<easy3d::SurfaceMesh::Vertex> face_vertices;
         for (auto p : plg)
         {
             easy3d::SurfaceMesh::Vertex v = mesh->add_vertex(p);
             face_vertices.push_back(v);
         }
             easy3d::SurfaceMesh::Face f = mesh->add_face(face_vertices);
             face_colors[f] = random_color();
         }

     }
     }

     create_drawables(mesh);
     easy3d::FacesDrawable* surface_drawable = mesh->faces_drawable("surface");
     surface_drawable->set_per_vertex_color(true);	// vertices have different colors
     this->add_model(mesh);
     std::cout << mesh->n_faces()<<"candidate faces extracted from point cloud " << '\n'<< std::endl ;

     update();


}



std::vector<Polygon3> MyViewer::split_polygon(Polygon3 polygon, Polygon3 plane_vector, Plane_3 plane, std::vector<float> box_limits)
{
    CGAL::Object result;
    Point_3 int_point;
    Plane_3 int_plane;
    Line_3 int_line;

    Polygon3 left;
    Polygon3 right ;

    std::vector<Polygon3> split_polygons;
    std::vector<Point_3> points;
    std::vector<Line_3> lines;
    std::vector<easy3d::vec3> line_seg ;
    std::vector<Point_3> line_seg1;


    for (auto p : polygon)
    {
        points.push_back(Point_3(p[0],p[1],p[2]));
    }

    if(points.size() > 2)
    {
    for (std::size_t i = 0; i < points.size()-1; ++i) {

         lines.push_back(Line_3 (points[i],points[i+1]));

    }
    lines.push_back(Line_3 (points[points.size()-1],points[0]));

    for (std::size_t i = 0; i < lines.size(); ++i) {

         Line_3 line = lines[i];

         result = CGAL::intersection( plane,line);

               if (CGAL::assign(int_point, result)) {

                   float x = int_point[0];
                   float y = int_point[1];
                   float z = int_point[2];

                 // store only points within bbox
                 bool b1 = box_limits[0] <= x && box_limits[1] >= x ;
                 bool b2 = box_limits[2] <= y && box_limits[3] >= y ;
                 bool b3 = box_limits[4] <= z && box_limits[5] >= z ;
                 if(b1 && b2 && b3)
                 {
                     easy3d::vec3 new_point(int_point[0],int_point[1],int_point[2]);

                     //creating each line segment
                     line_seg.push_back(new_point);
                     line_seg1.push_back(int_point);
                 }
               }
        }

    if (line_seg.size() == 2 )
    {

    for (auto p : polygon)
    {
       float d = easy3d::dot(plane_vector[1],(p - line_seg[0]));

       if (d >0)
       { left.push_back(p);}
       else if (d<0)
       {
       right.push_back(p);
       }

    }

    left.push_back(line_seg[1]);
    left.push_back(line_seg[0]);
    right.push_back(line_seg[0]);
    right.push_back(line_seg[1]);

   if(left.size() > 2 && right.size() >2)
   {
       split_polygons.push_back(left);
       split_polygons.push_back(right);
       return split_polygons;
   }
   else {
       return split_polygons;
   }
    }

    else {

    return split_polygons;
    }

    }

    else {
    return split_polygons;
    }

}
