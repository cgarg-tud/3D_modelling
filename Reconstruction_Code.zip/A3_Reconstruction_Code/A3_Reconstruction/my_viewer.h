#ifndef MY_VIEWER_H
#define MY_VIEWER_H
/*
*	Copyright (C) 2015 by Liangliang Nan (liangliang.nan@gmail.com)
*	https://3d.bk.tudelft.nl/liangliang/
*
*	This file is part of the GEO1004 assignment code framework.
*/

#include <easy3d/viewer.h>

//CGAL libararies
#if 0
#include <CGAL/Cartesian.h>
#include <CGAL/enum.h>
#include <CGAL/Plane_3.h>
#include <CGAL/Point_3.h>

#include <CGAL/Line_3.h>

#include <CGAL/intersections.h>

typedef CGAL::Cartesian<double> Kernel;
typedef CGAL::Point_3<Kernel>   Point_3;
typedef CGAL::Vector_3<Kernel>  Vector_3;
typedef CGAL::Plane_3<Kernel>   Plane_3;
typedef CGAL::Line_3<Kernel>   Line_3;
typedef std::vector<easy3d::vec3> Polygon3;

#else
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>

typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef CGAL::Point_3<Kernel>   Point_3;
typedef CGAL::Vector_3<Kernel>  Vector_3;
typedef CGAL::Plane_3<Kernel>   Plane_3;
typedef CGAL::Line_3<Kernel>   Line_3;
typedef std::vector<easy3d::vec3> Polygon3;
#endif

class MyViewer : public easy3d::Viewer
{
public:
    MyViewer();
    ~MyViewer();

    // Returns the pointer of the loaded point cloud.
    // In case the model doesn't exist (e.g., not loaded to the viewer),
    // it will return NULL (== 0).
    easy3d::PointCloud* point_cloud();

    // Create a drawable and upload the necessary data to GPU to
    // visualize the normals.
    // The input to this function is the point cloud.
    void creat_normal_drawable(easy3d::PointCloud* cloud);

    void extract_planes(easy3d::PointCloud* cloud);
    void generate_candidate_faces(easy3d::PointCloud* cloud);

    std::vector<Polygon3> split_polygon(Polygon3 polygon, Polygon3 plane_vector, Plane_3 plane, std::vector<float> box_limits);

private:
    bool key_press_event(int key, int modifiers);

};

#endif
