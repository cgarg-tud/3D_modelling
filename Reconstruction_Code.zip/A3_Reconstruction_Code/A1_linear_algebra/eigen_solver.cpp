#include "eigen_symmetric.h"
#include "eigen_solver.h"

using namespace eigen;

EigenSolver::EigenSolver()
{

}


EigenSolver::~EigenSolver()
{

}


// compute the eigen values and eigen vectors of matrix m.
void EigenSolver::solve(const mat3& m) {

    // after computation:
    //  - the eigen values are stored in the member "m_eigen_values"
    //  - the eigen vectors are stored in the member "m_eigen_vectors"

    // TODO -> call the function defined in "eigen_symmetric.h"
    // Please read carefully the manual of the function.


    float M[6], EVL[3], EVC[9];

    int t = 0;
    for (int i = 0; i < 3; i++)
    {
     for (int j = 0; j <= i; j++)
     {
        M[t++] = m(i,j);
     }

    }

    eigen_symmetric (M,3,EVC,EVL);
    for(int z = 0; z < 3; z++)
    {

        this->m_eigen_values[z] = EVL[z];
    }
    for (int k = 0; k < 3; k++)
    {
        for (int l = 0; l < 3; l++)
        {
            this->m_eigen_vectors[k](l) = EVC[3*k + l];

        }
     }

}
